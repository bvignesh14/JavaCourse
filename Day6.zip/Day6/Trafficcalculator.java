package Day6;
import java.util.Scanner;

public class Trafficcalculator {
	public static void main(String [] args ){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Vechile Type(2 for 2-Wheeler or 4 for 4-Wheeler");
		int Vechiletype = scan.nextInt();
		System.out.println("Enter your Speed:");
		int ActualSpeed = scan.nextInt();
		System.out.println("Enter your Speed Limit :");
		int Speedlimit = scan.nextInt();
		int Extraspeed = ActualSpeed - Speedlimit;
		
		if(Vechiletype == 2) {
			if(Extraspeed >= 1 && Extraspeed <10) {
				System.out.println("Fine:$500");
			}else if (Extraspeed >= 10 && Extraspeed <=20){
					System.out.println("Fine:$1000");
			} else if(Extraspeed > 20) {
				System.out.println("Fine:$2000");
			}
			else {
				System.out.println("No fine ,drive safely");
			}
		} else if (Vechiletype == 4) {
			if(Extraspeed >= 1 && Extraspeed <10) {
				System.out.println("Fine:$1000");
			}else if (Extraspeed >= 10 && Extraspeed <=20){
					System.out.println("Fine:$2000");
			} else if(Extraspeed > 20) {
				System.out.println("Fine:$3000");
		    } 
		} else {
			System.out.println("Invalid Data");
		}	
	}
}

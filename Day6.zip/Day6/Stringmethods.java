package Day6;
import java.util.Scanner;
public class Stringmethods {
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String str = "  HelloWorld123@Java  ";

        System.out.println("Original String: \"" + str + "\"");

        // 1. length()
        System.out.println("Length: " + str.length());

        // 2. charAt(int index)
        System.out.println("Character at index 2: " + str.charAt(2));

        // 3. substring(int beginIndex)
        System.out.println("Substring from index 5: " + str.substring(5));

        // 4. substring(int beginIndex, int endIndex)
        System.out.println("Substring from index 2 to 7: " + str.substring(2, 7));

        // 5. toLowerCase()
        System.out.println("Lowercase: " + str.toLowerCase());

        // 6. toUpperCase()
        System.out.println("Uppercase: " + str.toUpperCase());

        // 7. equals(String anotherString)
        System.out.println("Equals 'helloworld': " + str.trim().equals("helloworld"));

        // 8. equalsIgnoreCase(String anotherString)
        System.out.println("EqualsIgnoreCase 'helloworld123@java': " + str.trim().equalsIgnoreCase("helloworld123@java"));

        // 9. contains(CharSequence sequence)
        System.out.println("Contains 'Java': " + str.contains("Java"));

        // 10. startsWith(String prefix)
        System.out.println("Starts with '  Hell': " + str.startsWith("  Hell"));

        // 11. endsWith(String suffix)
        System.out.println("Ends with 'Java  ': " + str.endsWith("Java  "));

        // 12. indexOf(int ch)
        System.out.println("Index of 'W': " + str.indexOf('W'));

        // 13. indexOf(String str)
        System.out.println("Index of 'World': " + str.indexOf("World"));

        // 14. lastIndexOf(String str)
        System.out.println("Last Index of 'a': " + str.lastIndexOf("a"));

        // 15. replace(char oldChar, char newChar)
        System.out.println("Replace 'a' with 'x': " + str.replace('a', 'x'));

        // 16. trim()
        System.out.println("Trimmed String: \"" + str.trim() + "\"");

        // 17. isEmpty()
        String emptyStr = "";
        System.out.println("Is empty string empty? " + emptyStr.isEmpty());

        // 18. split(String regex)
        String data = "apple,banana,grape";
        String[] fruits = data.split(",");
        System.out.println("Split result of 'apple,banana,grape':");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }

        // 19. concat(String str)
        String greeting = "Hello";
        String name = "World";
        System.out.println("Concatenated String: " + greeting.concat(" ").concat(name));

        scan.close();
    }
}

package Day9;

public class ArrayEx {
	public static void main(String[] args) {
		String[] arr = {"sam","vijay","jagan","rahul"};
//		arr[0] = "Apple";
//		arr[1] = "Orange";
//		arr[2] = "Mango";
//		arr[3] = "Kiwi";
//		
//		for(String s : arr) {
//			System.out.println(s);
//		}
		
		for(int i = 0;i < arr.length;i++) {
			if (arr[i].equals("jagan")) {
				arr [i] = "sam";
			}
		}
		for(String s : arr) {
			System.out.println(s);
		}
	}
}

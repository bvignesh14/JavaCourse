package Day9;

public class ForEachEx {
	public static void main(String[] args) {
		String a[]= {"Vicky","pradeep","gokul","vignesh"};
		for(int i=0;i<a.length;i++) {
			if(a[i].equals("Vic")) {
				a[i]="Vicky";
			}
	
		}
		for (String b:a) {
			    	System.out.println(b);
			    }
	}

}


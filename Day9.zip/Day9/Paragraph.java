package Day9;
public class Paragraph {
	public static void main(String[] args) {
		String s = "A paragraph is a series of sentences that are organized and coherent, and are all related to a single topic. Almost every piece of writing you do that is longer than a few sentences should be organized into paragraphs.";
		int count = 0;
		 for(int i = 0; i<s.length();i++) {
			 if(s.charAt(i) == 'i') {
				 count++;
			 }
		 }
		 System.out.println(count);
	}
}

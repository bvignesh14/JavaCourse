package Day12;

public class MainUser {
	public static void main(String[] args) {
		IndianBank user=new IndianBank();
		user.setid(10);
		System.out.println("customer id is :"+(user.getid()));
		System.out.println("customer Name is: "+(user.name));
		System.out.println("Account number is :"+(user.accountno));
		user.setpin(2004);
		System.out.println("enter the pin :"+(user.getpin()));
		System.out.println("Balance is :"+(user.balance));
	}

}


package Day12;

public class Encapsulation {
	public static void main(String[] args) {
		
		Book book1 = new Book();
		book1.setBookName("Gokul - The Romeo");
		System.out.println(book1.getBookName());
		book1.setAuthorName("Gokul");
		System.out.println(book1.getAuthorName());
		book1.setId(1234);
		System.out.println(book1.getId());
		book1.setPrice(1000000.00);
		System.out.println(book1.getPrice());
		
		
	}
}

class Book {
	private int id;
	private String bookName;
	private String authorName; 
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}

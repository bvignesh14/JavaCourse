package Day2;

public class DataType {

	public static void main(String[] args) {
		int a =5;
		float b =5.5f;
		boolean c = true;
		byte d = 126;
		short e = 14;
		long f= 3263534434l;
		double g= 454.9879;
		char h= 'a';
		System.out.println("the integer:"+a);
		System.out.println("the float:"+b);
		System.out.println("the boolean:"+c);
		System.out.println("the byte:"+d);
		System.out.println("the short:"+e);
		System.out.println("the long:"+f);
		System.out.println("the double:"+g);
		System.out.println("the character:"+h);

	}

}
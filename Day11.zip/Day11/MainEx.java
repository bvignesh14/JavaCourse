package Day11;

import java.util.Scanner;


public class MainEx {
	public static void main(String[] args) {
		EmployeeOops emp1=new EmployeeOops();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter details of emp 1: ");
		emp1.id=sc.nextInt();
		sc.nextLine();
		emp1.name=sc.nextLine();
		emp1.number=sc.nextLong();
		emp1.salary=sc.nextFloat();
		emp1.result();
		
		EmployeeOops emp2=new EmployeeOops();
		emp2.id=2;
		emp2.name="vishal";
		emp2.number=9843292192l;
		emp2.salary=6000f;
		emp2.result();
		
		EmployeeOops emp3=new EmployeeOops();
		emp3.id=3;
		emp3.name="vignesh";
		emp3.number=9843292192l;
		emp3.salary=7000f;
		emp3.result();
		
		EmployeeOops emp4=new EmployeeOops();
		emp4.id=4;
		emp4.name="pradeep";
		emp4.number=9843292192l;
		emp4.salary=8000f;
		emp4.result();
	
	
	}

}


package Day8;
import java.util.Scanner;
public class Palindrome {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Word");
		String word = scan.next();
		String str = word.trim();
		String rev = "";
		for(int i = str.length()-1;i>=0;i++) {
			rev = rev+str.charAt(i);
		}
		System.out.println(rev);
		if(str.equals(rev)) {
			System.out.println("Palindrome");
		} else {
			System.out.println("Not a Palindrome");
		}
	}
}

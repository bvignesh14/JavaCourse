package Day4;

import java.util.Scanner;

public class ConditionalStatement {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the marks");
		int mark=sc.nextInt();
		if (mark>=35 && mark<=100) {
			System.out.println("Pass");
		}
		else if(mark<0 || mark>100) {
			System.out.println("invalid marks");
		}
		else {
			System.out.println("Fail");
		}
	}

}

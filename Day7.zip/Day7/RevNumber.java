package Day7;

public class RevNumber {
	public static void main(String[] args) {
		for(int i=50;i>=1;i--) {
			System.out.println("rev order :"+i);
			
		}
	}

}


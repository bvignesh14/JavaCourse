package Day7;

public class LoopExample {
	public static void main(String[] args) {
		for (int i = 1 ; i<=1000; i++){
			System.out.println("iteration:" +i);
		}
		for (int j = 1000; j>=1;j--){
			System.out.println("iteration:" +j);
		}
	}

}
